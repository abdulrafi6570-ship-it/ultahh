# Tempel Twiboon

Web app buat tempel foto ke template twibbon/photocard. Sudah include 10 template siap pakai, dan bisa upload template sendiri.

## Cara pakai di Replit

1. Buat Repl baru → pilih **Node.js** (atau import repo/upload semua file dari zip ini).
2. Upload/paste seluruh isi folder ini (jaga struktur folder: `public/`, `templates/`, `server.js`, `package.json`, `.replit`).
3. Klik tombol **Run**. Replit otomatis `npm install` lalu jalanin server.
4. Buka preview webview yang muncul — itu web app-nya.

## Cara kerja

- **Deteksi kotak otomatis**: saat template dipilih, app scan semua pixel dan cari area yang putih polos/transparan (biasanya itu "kotak foto" di desain twibbon), lalu group jadi kotak-kotak pakai flood fill. Area yang nempel ke pinggir/sudut gambar dianggap background, bukan kotak — jadi otomatis di-skip.
- **Tap kotak kosong** → buka galeri/kamera → pilih foto → foto otomatis di-crop biar nutupin seluruh kotak (kayak object-fit: cover).
- **Drag** = geser posisi foto dalam kotak. **Scroll / pinch / tombol +−** = zoom. Foto dikunci (clamped) supaya nggak pernah nyisain celah kosong dan nggak pernah keluar dari garis kotak — karena di-clip persis ke bentuk kotak aslinya (pakai canvas masking), bukan cuma kotak persegi biasa.
- Kalau auto-detect kurang pas / ada kotak yang kelewat, pakai **"Tambah Kotak Manual"** lalu gambar kotaknya sendiri di canvas, atau **"Hapus Kotak"** buat hapus kotak yang salah deteksi.
- Progress bar nunjukin "x/y kotak terisi". Tombol **Simpan** baru aktif kalau semua kotak udah keisi.
- **Simpan** = export hasil akhir jadi 1 file PNG resolusi asli template, siap di-share/upload.

## Struktur folder

```
public/
  index.html
  style.css
  app.js
templates/
  manifest.json      <- daftar template + nama file
  t1-idcard.jpg ... t10-lovelydate.jpg
server.js
package.json
.replit
```

## Nambah template baru sendiri

Paling gampang lewat tombol **"Upload Template Sendiri"** di app (nggak perlu edit kode) — asal templatenya punya area putih polos atau transparan sebagai "kotak foto", auto-detect bakal nemuin sendiri.

Kalau mau template itu permanen muncul di galeri pilihan, taruh file gambarnya di folder `templates/`, terus tambahin baris baru di `templates/manifest.json`:

```json
{"id":"t11","name":"Nama Template","file":"nama-file.jpg"}
```

## Catatan

3 gambar contoh yang dikirim (2 photocard CORTIS + 1 collage "seonghyeon p") sengaja nggak dimasukin sebagai template, karena itu udah berisi foto orang lain secara permanen (bukan kotak kosong yang bisa diisi ulang).
