/* ===================== Tempel Twiboon ===================== */

const state = {
  templateImg: null,     // HTMLImageElement, natural size
  natW: 0, natH: 0,
  labels: null,          // Int32Array, per-pixel component id (-1 = not empty)
  slots: [],             // {id, minX,minY,maxX,maxY, layer:canvas, mask:canvas, photo:{img,scale,ox,oy,minScale}|null, manual:bool}
  nextSlotId: 1,
  holeTemplateCanvas: null, // template with slot pixels alpha=0
  activeSlot: null,
  displayScale: 1,       // canvas pixel -> CSS pixel ratio
};

const el = {
  templatePicker: document.getElementById('templatePicker'),
  templateGrid: document.getElementById('templateGrid'),
  customTemplateInput: document.getElementById('customTemplateInput'),
  editor: document.getElementById('editor'),
  canvas: document.getElementById('mainCanvas'),
  work: document.getElementById('workCanvas'),
  progressText: document.getElementById('progressText'),
  downloadBtn: document.getElementById('downloadBtn'),
  backBtn: document.getElementById('backBtn'),
  addBoxBtn: document.getElementById('addBoxBtn'),
  delBoxBtn: document.getElementById('delBoxBtn'),
  zoomInBtn: document.getElementById('zoomInBtn'),
  zoomOutBtn: document.getElementById('zoomOutBtn'),
  photoInput: document.getElementById('photoInput'),
  hintBubble: document.getElementById('hintBubble'),
};
const ctx = el.canvas.getContext('2d');

/* ---------- 1. Load template gallery ---------- */
fetch('/templates/manifest.json')
  .then(r => r.json())
  .then(list => {
    list.forEach(t => {
      const card = document.createElement('div');
      card.className = 'template-card';
      card.innerHTML = `<img src="/templates/${t.file}" loading="lazy"><span>${t.name}</span>`;
      card.addEventListener('click', () => loadTemplateFromURL(`/templates/${t.file}`));
      el.templateGrid.appendChild(card);
    });
  });

el.customTemplateInput.addEventListener('change', e => {
  const f = e.target.files[0];
  if (!f) return;
  const url = URL.createObjectURL(f);
  loadTemplateFromURL(url);
});

function loadTemplateFromURL(url) {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    state.templateImg = img;
    state.natW = img.naturalWidth;
    state.natH = img.naturalHeight;
    el.templatePicker.classList.add('hidden');
    el.editor.classList.remove('hidden');
    detectSlots();
  };
  img.src = url;
}

/* ---------- 2. Auto-detect empty box regions ---------- */
function detectSlots() {
  const w = state.natW, h = state.natH;
  el.work.width = w; el.work.height = h;
  const wctx = el.work.getContext('2d', { willReadFrequently: true });
  wctx.clearRect(0, 0, w, h);
  wctx.drawImage(state.templateImg, 0, 0, w, h);
  const data = wctx.getImageData(0, 0, w, h).data;

  let isEmpty = new Uint8Array(w * h);
  for (let i = 0, p = 0; i < data.length; i += 4, p++) {
    const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
    if (a < 15) { isEmpty[p] = 1; continue; }
    const brightness = (r + g + b) / 3;
    const sat = Math.max(r, g, b) - Math.min(r, g, b);
    if (brightness > 195 && sat < 40) isEmpty[p] = 1;
  }

  // Erode a few px: severs thin anti-aliased bridges between adjacent boxes
  // or between a box and the outer background, without needing to know colors.
  const ERODE = 5;
  for (let it = 0; it < ERODE; it++) {
    const next = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const p = y * w + x;
        if (!isEmpty[p]) continue;
        const okL = x > 0 && isEmpty[p - 1];
        const okR = x < w - 1 && isEmpty[p + 1];
        const okU = y > 0 && isEmpty[p - w];
        const okD = y < h - 1 && isEmpty[p + w];
        if (okL && okR && okU && okD) next[p] = 1;
      }
    }
    isEmpty = next;
  }

  const labels = new Int32Array(w * h).fill(-1);
  let nextLabel = 0;
  const stack = new Int32Array(w * h);
  const compBBox = []; // {minX,minY,maxX,maxY,area}

  for (let start = 0; start < w * h; start++) {
    if (!isEmpty[start] || labels[start] !== -1) continue;
    let sp = 0;
    stack[sp++] = start;
    labels[start] = nextLabel;
    let minX = start % w, maxX = minX, minY = (start / w) | 0, maxY = minY, area = 0;
    while (sp > 0) {
      const p = stack[--sp];
      area++;
      const x = p % w, y = (p / w) | 0;
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      // 4-neighbors
      if (x > 0) { const q = p - 1; if (isEmpty[q] && labels[q] === -1) { labels[q] = nextLabel; stack[sp++] = q; } }
      if (x < w - 1) { const q = p + 1; if (isEmpty[q] && labels[q] === -1) { labels[q] = nextLabel; stack[sp++] = q; } }
      if (y > 0) { const q = p - w; if (isEmpty[q] && labels[q] === -1) { labels[q] = nextLabel; stack[sp++] = q; } }
      if (y < h - 1) { const q = p + w; if (isEmpty[q] && labels[q] === -1) { labels[q] = nextLabel; stack[sp++] = q; } }
    }
    compBBox[nextLabel] = { minX, minY, maxX, maxY, area };
    nextLabel++;
  }

  state.labels = labels;
  state.slots = [];
  state.nextSlotId = 1;

  const minArea = Math.max(1200, w * h * 0.003);
  const margin = ERODE + 8;
  const found = [];
  for (let lbl = 0; lbl < nextLabel; lbl++) {
    const b = compBBox[lbl];
    if (b.area < minArea) continue;
    const bw = b.maxX - b.minX, bh = b.maxY - b.minY;
    if (bw < 20 || bh < 20) continue;
    if (bw > 0.85 * w && bh > 0.85 * h) continue; // whole-canvas background blob
    if (b.minX <= margin || b.minY <= margin || b.maxX >= w - margin || b.maxY >= h - margin) continue; // touches outer edge
    found.push({ lbl, ...b });
  }
  found.sort((a, b2) => a.minY - b2.minY || a.minX - b2.minX);

  found.forEach(f => {
    const id = state.nextSlotId++;
    state.slots.push({
      id, label: f.lbl, minX: f.minX, minY: f.minY, maxX: f.maxX, maxY: f.maxY,
      photo: null, manual: false, mask: buildMaskFromLabel(w, h, labels, f.lbl),
      layer: document.createElement('canvas'),
    });
  });

  rebuildHoleTemplate();
  setupCanvasSize();
  redrawAll();
  updateProgress();
}

function buildMaskFromLabel(w, h, labels, lbl) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const cctx = c.getContext('2d');
  const imgData = cctx.createImageData(w, h);
  for (let p = 0; p < w * h; p++) {
    if (labels[p] === lbl) {
      imgData.data[p * 4 + 3] = 255;
    }
  }
  cctx.putImageData(imgData, 0, 0);
  return c;
}

function buildMaskFromRect(w, h, minX, minY, maxX, maxY) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const cctx = c.getContext('2d');
  cctx.fillStyle = '#fff';
  cctx.fillRect(minX, minY, maxX - minX, maxY - minY);
  return c;
}

/* punch transparent holes into a copy of the template at slot regions */
function rebuildHoleTemplate() {
  const w = state.natW, h = state.natH;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const cctx = c.getContext('2d');
  cctx.drawImage(state.templateImg, 0, 0, w, h);
  const imgData = cctx.getImageData(0, 0, w, h);
  const d = imgData.data;
  state.slots.forEach(s => {
    const mctx = s.mask.getContext('2d');
    const mdata = mctx.getImageData(0, 0, w, h).data;
    for (let p = 0; p < w * h; p++) {
      if (mdata[p * 4 + 3] > 0) d[p * 4 + 3] = 0;
    }
  });
  cctx.putImageData(imgData, 0, 0);
  state.holeTemplateCanvas = c;
}

/* ---------- 3. Canvas sizing & render ---------- */
function setupCanvasSize() {
  el.canvas.width = state.natW;
  el.canvas.height = state.natH;
  const maxCssWidth = Math.min(window.innerWidth - 24, 480);
  el.canvas.style.width = maxCssWidth + 'px';
  el.canvas.style.height = (maxCssWidth * state.natH / state.natW) + 'px';
  state.displayScale = state.natW / maxCssWidth;
}
window.addEventListener('resize', () => { if (state.templateImg) setupCanvasSize(); });

function renderSlotLayer(slot) {
  const w = state.natW, h = state.natH;
  slot.layer.width = w; slot.layer.height = h;
  const lctx = slot.layer.getContext('2d');
  lctx.clearRect(0, 0, w, h);
  if (!slot.photo) return;
  const ph = slot.photo;
  lctx.save();
  lctx.translate(ph.ox, ph.oy);
  lctx.scale(ph.scale, ph.scale);
  lctx.drawImage(ph.img, -ph.img.width / 2, -ph.img.height / 2);
  lctx.restore();
  lctx.globalCompositeOperation = 'destination-in';
  lctx.drawImage(slot.mask, 0, 0);
  lctx.globalCompositeOperation = 'source-over';
}

function redrawAll() {
  const w = state.natW, h = state.natH;
  ctx.clearRect(0, 0, w, h);
  state.slots.forEach(s => ctx.drawImage(s.layer, 0, 0));
  ctx.drawImage(state.holeTemplateCanvas, 0, 0);
  // plus icons on empty slots
  state.slots.forEach(s => {
    if (s.photo) return;
    const cx = (s.minX + s.maxX) / 2, cy = (s.minY + s.maxY) / 2;
    const r = Math.max(18, Math.min(34, (s.maxX - s.minX) * 0.12));
    ctx.save();
    ctx.globalAlpha = state.activeSlot === s.id ? 1 : 0.85;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fill();
    ctx.strokeStyle = '#ff7fb0';
    ctx.lineWidth = Math.max(2, r * 0.08);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.5, cy); ctx.lineTo(cx + r * 0.5, cy);
    ctx.moveTo(cx, cy - r * 0.5); ctx.lineTo(cx, cy + r * 0.5);
    ctx.strokeStyle = '#ff7fb0';
    ctx.lineWidth = Math.max(2, r * 0.12);
    ctx.stroke();
    ctx.restore();
  });
  // highlight ring on active slot border if it has a photo (for drag feedback)
  const active = state.slots.find(s => s.id === state.activeSlot);
  if (active) {
    ctx.save();
    ctx.strokeStyle = '#ff4fa0';
    ctx.lineWidth = Math.max(3, w * 0.004);
    ctx.setLineDash([10, 8]);
    ctx.strokeRect(active.minX, active.minY, active.maxX - active.minX, active.maxY - active.minY);
    ctx.restore();
  }
}

function updateProgress() {
  const total = state.slots.length;
  const filled = state.slots.filter(s => s.photo).length;
  el.progressText.textContent = `${filled}/${total} kotak terisi`;
  el.downloadBtn.disabled = !(total > 0 && filled === total);
  const next = state.slots.find(s => !s.photo);
  if (next && filled < total) {
    el.hintBubble.classList.remove('hidden');
    el.hintBubble.textContent = filled === 0 ? 'Yuk isi kotak yang masih kosong ⬇️' : 'Masih ada kotak kosong, isi dulu yuk ⬇️';
  } else {
    el.hintBubble.classList.add('hidden');
  }
}

/* ---------- 4. Coordinate helpers ---------- */
function canvasPointFromEvent(e) {
  const rect = el.canvas.getBoundingClientRect();
  const cx = (e.clientX - rect.left) * (state.natW / rect.width);
  const cy = (e.clientY - rect.top) * (state.natH / rect.height);
  return { x: cx, y: cy };
}
function slotAt(x, y) {
  for (const s of state.slots) {
    if (x >= s.minX && x <= s.maxX && y >= s.minY && y <= s.maxY) {
      const mctx = s.mask.getContext('2d');
      const px = mctx.getImageData(Math.min(x, state.natW - 1), Math.min(y, state.natH - 1), 1, 1).data;
      if (px[3] > 0) return s;
    }
  }
  return null;
}

/* ---------- 5. Photo placement ---------- */
let pendingSlot = null;
el.photoInput.addEventListener('change', e => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f || !pendingSlot) return;
  const url = URL.createObjectURL(f);
  const img = new Image();
  img.onload = () => {
    const s = pendingSlot;
    const bw = s.maxX - s.minX, bh = s.maxY - s.minY;
    const minScale = Math.max(bw / img.width, bh / img.height) * 1.02;
    s.photo = {
      img,
      scale: minScale,
      minScale,
      ox: (s.minX + s.maxX) / 2,
      oy: (s.minY + s.maxY) / 2,
    };
    renderSlotLayer(s);
    state.activeSlot = s.id;
    redrawAll();
    updateProgress();
  };
  img.src = url;
});

function openPhotoPickerFor(slot) {
  pendingSlot = slot;
  el.photoInput.click();
}

/* ---------- 6. Drag & zoom interactions ---------- */
let dragState = null; // {slot, startX, startY, startOx, startOy}
let pinchState = null;

el.canvas.addEventListener('pointerdown', e => {
  if (addingBox) return;
  const pt = canvasPointFromEvent(e);
  const s = slotAt(pt.x, pt.y);
  if (!s) return;
  if (!s.photo) { openPhotoPickerFor(s); return; }
  state.activeSlot = s.id;
  dragState = { slot: s, startX: pt.x, startY: pt.y, startOx: s.photo.ox, startOy: s.photo.oy };
  el.canvas.setPointerCapture(e.pointerId);
  redrawAll();
});
el.canvas.addEventListener('pointermove', e => {
  if (!dragState) return;
  const pt = canvasPointFromEvent(e);
  const dx = pt.x - dragState.startX, dy = pt.y - dragState.startY;
  const s = dragState.slot;
  s.photo.ox = dragState.startOx + dx;
  s.photo.oy = dragState.startOy + dy;
  clampPhoto(s);
  renderSlotLayer(s);
  redrawAll();
});
function endDrag() { dragState = null; }
el.canvas.addEventListener('pointerup', endDrag);
el.canvas.addEventListener('pointercancel', endDrag);

el.canvas.addEventListener('wheel', e => {
  const pt = canvasPointFromEvent(e);
  const s = slotAt(pt.x, pt.y);
  if (!s || !s.photo) return;
  e.preventDefault();
  const factor = e.deltaY < 0 ? 1.06 : 0.94;
  applyZoom(s, factor);
}, { passive: false });

// simple pinch-to-zoom for touch
el.canvas.addEventListener('touchstart', e => {
  if (e.touches.length === 2) {
    const pt1 = e.touches[0], pt2 = e.touches[1];
    const mid = { clientX: (pt1.clientX + pt2.clientX) / 2, clientY: (pt1.clientY + pt2.clientY) / 2 };
    const cpt = canvasPointFromEvent(mid);
    const s = slotAt(cpt.x, cpt.y);
    if (!s || !s.photo) return;
    dragState = null;
    pinchState = { slot: s, startDist: dist(pt1, pt2), startScale: s.photo.scale };
  }
}, { passive: true });
el.canvas.addEventListener('touchmove', e => {
  if (pinchState && e.touches.length === 2) {
    const d = dist(e.touches[0], e.touches[1]);
    const s = pinchState.slot;
    const newScale = Math.max(s.photo.minScale, pinchState.startScale * (d / pinchState.startDist));
    s.photo.scale = newScale;
    clampPhoto(s);
    renderSlotLayer(s);
    redrawAll();
  }
}, { passive: true });
el.canvas.addEventListener('touchend', e => { if (e.touches.length < 2) pinchState = null; });
function dist(a, b) { return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); }

function applyZoom(s, factor) {
  s.photo.scale = Math.max(s.photo.minScale, Math.min(s.photo.minScale * 6, s.photo.scale * factor));
  clampPhoto(s);
  renderSlotLayer(s);
  redrawAll();
}
el.zoomInBtn.addEventListener('click', () => { const s = activeSlotObj(); if (s) applyZoom(s, 1.12); });
el.zoomOutBtn.addEventListener('click', () => { const s = activeSlotObj(); if (s) applyZoom(s, 0.89); });
function activeSlotObj() { return state.slots.find(s => s.id === state.activeSlot && s.photo); }

function clampPhoto(s) {
  const ph = s.photo;
  const halfW = (ph.img.width * ph.scale) / 2;
  const halfH = (ph.img.height * ph.scale) / 2;
  const minCx = s.minX, maxCx = s.maxX, minCy = s.minY, maxCy = s.maxY;
  // keep image covering the bbox: clamp center so edges never fall inside bbox
  const loX = Math.min(minCx + halfW, (minCx + maxCx) / 2);
  const hiX = Math.max(maxCx - halfW, (minCx + maxCx) / 2);
  const loY = Math.min(minCy + halfH, (minCy + maxCy) / 2);
  const hiY = Math.max(maxCy - halfH, (minCy + maxCy) / 2);
  ph.ox = Math.min(Math.max(ph.ox, loX), hiX);
  ph.oy = Math.min(Math.max(ph.oy, loY), hiY);
}

/* ---------- 7. Manual box add / delete ---------- */
let addingBox = false;
let drawStart = null;
el.addBoxBtn.addEventListener('click', () => {
  addingBox = !addingBox;
  el.addBoxBtn.textContent = addingBox ? '✏️ Gambar kotak di canvas...' : '➕ Tambah Kotak Manual';
});
el.canvas.addEventListener('pointerdown', e => {
  if (!addingBox) return;
  drawStart = canvasPointFromEvent(e);
}, true);
el.canvas.addEventListener('pointerup', e => {
  if (!addingBox || !drawStart) return;
  const p2 = canvasPointFromEvent(e);
  const minX = Math.min(drawStart.x, p2.x), maxX = Math.max(drawStart.x, p2.x);
  const minY = Math.min(drawStart.y, p2.y), maxY = Math.max(drawStart.y, p2.y);
  drawStart = null;
  if (maxX - minX < 20 || maxY - minY < 20) return;
  const id = state.nextSlotId++;
  const mask = buildMaskFromRect(state.natW, state.natH, minX, minY, maxX, maxY);
  state.slots.push({
    id, label: -1, minX, minY, maxX, maxY, photo: null, manual: true,
    mask, layer: document.createElement('canvas'),
  });
  addingBox = false;
  el.addBoxBtn.textContent = '➕ Tambah Kotak Manual';
  rebuildHoleTemplate();
  redrawAll();
  updateProgress();
}, true);

el.delBoxBtn.addEventListener('click', () => {
  if (!state.activeSlot) return;
  state.slots = state.slots.filter(s => s.id !== state.activeSlot);
  state.activeSlot = null;
  rebuildHoleTemplate();
  redrawAll();
  updateProgress();
  el.delBoxBtn.disabled = true;
});
el.canvas.addEventListener('pointerdown', e => {
  const pt = canvasPointFromEvent(e);
  const s = slotAt(pt.x, pt.y);
  el.delBoxBtn.disabled = !s;
});

/* ---------- 8. Back to template picker ---------- */
el.backBtn.addEventListener('click', () => {
  el.editor.classList.add('hidden');
  el.templatePicker.classList.remove('hidden');
  state.slots = [];
  state.activeSlot = null;
});

/* ---------- 9. Download ---------- */
el.downloadBtn.addEventListener('click', () => {
  const out = document.createElement('canvas');
  out.width = state.natW; out.height = state.natH;
  const octx = out.getContext('2d');
  state.slots.forEach(s => octx.drawImage(s.layer, 0, 0));
  octx.drawImage(state.holeTemplateCanvas, 0, 0);
  out.toBlob(blob => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'twiboon.png';
    a.click();
  }, 'image/png');
});
