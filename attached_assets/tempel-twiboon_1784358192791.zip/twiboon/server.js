const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const TEMPLATES_DIR = path.join(__dirname, 'templates');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

function serveFile(res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

function safeResolve(baseDir, urlPath) {
  const resolved = path.normalize(path.join(baseDir, urlPath));
  if (!resolved.startsWith(baseDir)) return null; // block path traversal
  return resolved;
}

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);

  if (urlPath.startsWith('/templates/')) {
    const rel = urlPath.replace('/templates/', '');
    const fp = safeResolve(TEMPLATES_DIR, rel);
    if (!fp) { res.writeHead(400); res.end('Bad request'); return; }
    return serveFile(res, fp);
  }

  if (urlPath === '/') urlPath = '/index.html';
  const fp = safeResolve(PUBLIC_DIR, urlPath);
  if (!fp) { res.writeHead(400); res.end('Bad request'); return; }
  fs.stat(fp, (err, stat) => {
    if (err || !stat.isFile()) { res.writeHead(404); res.end('Not found'); return; }
    serveFile(res, fp);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Tempel Twiboon jalan di http://localhost:${PORT}`);
});
